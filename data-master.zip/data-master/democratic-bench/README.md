# Democratic Bench

This folder contains data behind the story [Some Democrats Who Could Step Up If Hillary Isn’t Ready For Hillary](https://fivethirtyeight.com/features/some-democrats-who-could-step-up-if-hillary-isnt-ready-for-hillary/).

Header | Definition
---|---------
`cand` | Candidate
`raised_exp` | Amount the candidate was expected to raise
`raised_act` | Amount the candidate actually raised
