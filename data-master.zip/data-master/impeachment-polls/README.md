# Impeachment Polls

This folder contains the data behind [Do Americans Support Impeaching Trump?](https://fivethirtyeight.com/features/do-americans-support-impeaching-president-trump/)
