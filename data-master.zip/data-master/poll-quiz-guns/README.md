# Poll Quiz - Guns

This folder contains the data behind the quiz [Do You Know Where America Stands On Guns?](https://projects.fivethirtyeight.com/guns-parkland-polling-quiz/)

[`guns-polls.csv`](guns-polls.csv) contains the list of polls about guns that we used in our quiz. All polls have been taken after February 14, 2018, the date of the school shooting in Parkland, Florida.
