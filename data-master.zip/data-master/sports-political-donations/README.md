# sports-political-donations

This folder contains the data behind the story [Inside The Political Donation History Of Wealthy Sports Owners
](https://fivethirtyeight.com/features/inside-the-political-donation-history-of-wealthy-sports-owners/)

`sports-political-donations.csv` contains every confirmed partisan political contribution from team owners and commissioners in the NFL, NBA, WNBA, NHL, MLB and NASCAR. Only contributions while owners were involved with the team are included. The data is from the Federal Election Commission and OpenSecrets.
