# FiveThirtyEight's Partisan Lean (2020)

⚠️ The data in this folder is out of date. Please see the [toplevel folder in the `partisan-lean`](../) dataset for the most up-to-date partisan-lean numbers.

This directory contains the data for FiveThirtyEight's partisan lean, which is used in our election forecasts.

Partisan lean is the average difference between how a state or district votes and how the country votes overall, with 2016 presidential election results weighted 50 percent, 2012 presidential election results weighted 25 percent and results from elections for the state legislature weighted 25 percent.

