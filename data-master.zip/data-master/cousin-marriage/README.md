# Cousin Marriage

This folder contains data behind the story [Dear Mona: How Many Americans Are Married To Their Cousins?](https://fivethirtyeight.com/features/how-many-americans-are-married-to-their-cousins/)

Header | Definition
---|---------
`percent` | Percent of marriages that are consanguineous

Source: [cosang.net](http://www.consang.net/index.php/Main_Page)