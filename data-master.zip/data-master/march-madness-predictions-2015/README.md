# March Madness Predictions

This folder contains data behind the [2015 March Madness Predictions](http://fivethirtyeight.com/interactives/march-madness-predictions-2015/).

Data was updated each time we calculate new odds.
