# Early Senate Polls

This folder contains data behind the story [Early Senate Polls Have Plenty to Tell Us About November](https://fivethirtyeight.com/features/early-senate-polls-have-plenty-to-tell-us-about-november/).